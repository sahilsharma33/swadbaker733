# Swad Bakers — GitHub Pages frontend

This folder is a static GitHub Pages build of Swad Bakers.

## Deploy
1. Upload the contents of this folder to your GitHub repository.
2. In GitHub: **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`, then Save.
5. Open the generated Pages URL.

## Important
GitHub Pages only hosts static frontend files. Node.js/Express, MongoDB and Razorpay server code cannot run on GitHub Pages.

The frontend therefore uses its built-in demo data when `window.API_BASE` is not configured. To use the real database/API, deploy the backend separately and configure the frontend to call that backend.

## Changes made
- Embedded the complete `css/styles.css` into the HTML pages.
- Changed root links (`/`) to `index.html` so repository/project Pages paths work.
- Fixed the Products navigation link.
- Fixed shared `app.js` so it does not crash on pages that do not contain homepage elements.
- Fixed product-card selector mismatch (`.product-title`/`.product-desc` vs `.title`/`.meta`).
- Kept `.env` out of the deploy package.
